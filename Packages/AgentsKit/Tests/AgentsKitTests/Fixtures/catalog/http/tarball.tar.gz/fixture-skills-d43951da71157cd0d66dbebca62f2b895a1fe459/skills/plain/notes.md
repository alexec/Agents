Some notes.
