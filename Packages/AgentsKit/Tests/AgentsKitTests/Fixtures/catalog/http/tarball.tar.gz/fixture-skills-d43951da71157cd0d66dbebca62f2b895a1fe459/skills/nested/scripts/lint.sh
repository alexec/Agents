#!/bin/sh
echo lint
